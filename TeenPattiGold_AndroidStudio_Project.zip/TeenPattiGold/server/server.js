const WebSocket = require("ws");
const crypto = require("crypto");
const wss = new WebSocket.Server({ port: process.env.PORT || 8080 });
const rooms = new Map();
const players = new Map();

function code() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function broadcast(room, obj) {
  const r = rooms.get(room); if (!r) return;
  for (const p of r.players) send(p.ws, obj);
}
function deck() {
  const suits = ["♠", "♥", "♦", "♣"], ranks = ["A","K","Q","J","10","9","8","7","6","5","4","3","2"];
  const cards = suits.flatMap(s => ranks.map(v => `${v}${s}`));
  for (let i = cards.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1); [cards[i], cards[j]] = [cards[j], cards[i]];
  }
  return cards;
}
wss.on("connection", ws => {
  const player = { ws, name: "Player", room: null };
  players.set(ws, player);
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws, {type:"error", message:"Invalid message"}); }
    if (msg.type === "hello") {
      player.name = String(msg.name || "Player").slice(0,18);
      return send(ws, {type:"notice", message:`Welcome, ${player.name}`});
    }
    if (msg.type === "create") {
      let id; do { id = code(); } while (rooms.has(id));
      rooms.set(id, {players: [], deck: []});
      return join(id);
    }
    if (msg.type === "join") {
      const id = String(msg.room || "").toUpperCase();
      if (!rooms.has(id)) return send(ws, {type:"error", message:"Room not found"});
      return join(id);
    }
    if (msg.type === "deal") {
      const r = rooms.get(player.room);
      if (!r || r.players.length < 2) return send(ws, {type:"error", message:"At least two players are needed"});
      r.deck = deck();
      // Send three private cards to each connected player; no wager or stake exists.
      r.players.forEach((p, i) => send(p.ws, {type:"hand", cards:r.deck.slice(i*3, i*3+3)}));
      return broadcast(player.room, {type:"notice", message:"New friendly round dealt"});
    }
    function join(id) {
      const r = rooms.get(id);
      if (r.players.length >= 6) return send(ws, {type:"error", message:"Room is full"});
      if (player.room && rooms.has(player.room)) {
        const old = rooms.get(player.room); old.players = old.players.filter(p => p !== player);
      }
      player.room = id; r.players.push(player);
      send(ws, {type:"joined", room:id});
      broadcast(id, {type:"state", players:r.players.map(p => p.name)});
    }
  });
  ws.on("close", () => {
    const p = players.get(ws); players.delete(ws);
    if (p && p.room && rooms.has(p.room)) {
      const r = rooms.get(p.room); r.players = r.players.filter(x => x !== p);
      if (!r.players.length) rooms.delete(p.room);
      else broadcast(p.room, {type:"state", players:r.players.map(x => x.name)});
    }
  });
});
console.log(`Teen Patti Gold server listening on ${process.env.PORT || 8080}`);
