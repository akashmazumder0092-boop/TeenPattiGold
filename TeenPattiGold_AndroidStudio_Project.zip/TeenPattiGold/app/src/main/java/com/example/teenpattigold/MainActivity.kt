package com.example.teenpattigold

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import okhttp3.*
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val SERVER_URL = "ws://10.0.2.2:8080" // Android emulator -> host machine
private val felt = Color(0xFF075B43)
private val gold = Color(0xFFFFD36A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TeenPattiGoldApp() }
    }
}

@Composable
fun TeenPattiGoldApp() {
    var player by remember { mutableStateOf("Player") }
    var room by remember { mutableStateOf("") }
    var roomInput by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Connect to the online server to begin") }
    var events by remember { mutableStateOf(listOf<String>()) }
    var cards by remember { mutableStateOf(listOf<String>()) }
    var socket by remember { mutableStateOf<WebSocket?>(null) }
    val client = remember { OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build() }

    fun send(type: String, extra: JSONObject = JSONObject()) {
        val s = JSONObject().put("type", type)
        val keys = extra.keys()
        while (keys.hasNext()) { val k = keys.next(); s.put(k, extra.get(k)) }
        socket?.send(s.toString()) ?: run { status = "Not connected. Check server address." }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = gold, background = Color(0xFF09251D), surface = Color(0xFF12382C),
        onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
    )) {
        Column(Modifier.fillMaxSize().background(Color(0xFF09251D)).padding(18.dp)) {
            Text("TEEN PATTI GOLD", color = gold, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("ONLINE CARD TABLE • FRIENDLY SCORE MODE", color = Color.LightGray, fontSize = 11.sp)
            Spacer(Modifier.height(18.dp))
            OutlinedTextField(value = player, onValueChange = { player = it.take(18) },
                label = { Text("Player name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val req = Request.Builder().url(SERVER_URL).build()
                    socket = client.newWebSocket(req, object : WebSocketListener() {
                        override fun onOpen(webSocket: WebSocket, response: Response) {
                            status = "Connected to Teen Patti Gold server"
                            webSocket.send(JSONObject().put("type", "hello").put("name", player).toString())
                        }
                        override fun onMessage(webSocket: WebSocket, text: String) {
                            val obj = JSONObject(text)
                            when (obj.optString("type")) {
                                "joined" -> { room = obj.optString("room"); status = "Joined room $room" }
                                "state" -> {
                                    val names = obj.optJSONArray("players")
                                    val list = mutableListOf<String>()
                                    if (names != null) for (i in 0 until names.length()) list.add(names.getString(i))
                                    events = list.map { "Player: $it" }
                                }
                                "hand" -> {
                                    val a = obj.optJSONArray("cards")
                                    cards = if (a == null) emptyList() else (0 until a.length()).map { a.getString(it) }
                                    status = "Your cards are ready"
                                }
                                "notice" -> status = obj.optString("message")
                                "error" -> status = obj.optString("message")
                            }
                        }
                        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                            status = "Connection failed: ${t.localizedMessage ?: "server unavailable"}"
                        }
                    })
                }) { Text("Connect") }
                Button(onClick = { send("create") }) { Text("Create room") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(value = roomInput, onValueChange = { roomInput = it.uppercase().take(6) },
                label = { Text("Room code") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { send("join", JSONObject().put("room", roomInput)) },
                modifier = Modifier.fillMaxWidth()) { Text("Join room") }
            Spacer(Modifier.height(12.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF12382C)),
                modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp)) {
                    Text(status, color = gold, fontWeight = FontWeight.Bold)
                    Text(if (room.isBlank()) "Room: —" else "Room: $room", color = Color.White)
                    Text("Players in room", color = gold, fontWeight = FontWeight.Bold)
                    events.forEach { Text(it, color = Color.White) }
                    Button(onClick = { send("deal") }, enabled = room.isNotBlank()) {
                        Text("Deal cards (score-only)")
                    }
                    if (cards.isNotEmpty()) {
                        Text("Your hand", color = gold, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            cards.forEach { card ->
                                Card(colors = CardDefaults.cardColors(containerColor = Color.White),
                                    shape = RoundedCornerShape(10.dp)) {
                                    Text(card, color = Color.Black, fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("No betting, purchases, cash prizes or withdrawals. Rounds are for friendly play only.",
                color = Color.LightGray, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            Text("Prototype • Set SERVER_URL to your hosted WebSocket server before release",
                color = Color.Gray, fontSize = 10.sp)
        }
    }
}
